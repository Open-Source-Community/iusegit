# Learning Resources

This file contains learning materials shared by contributors

## Videos:
* [Watch this (Arabic) video to know what git is.](https://www.youtube.com/watch?v=HEmfKX3prdA)
* [Let Bucky teach how to use Git :D](https://www.youtube.com/watch?v=cEGIFZDyszA&index=1&list=PL6gx4Cwl9DGAKWClAD_iKpNC0bGHxGhcx)
* [Watch an introduction from Traversy Media.](https://www.youtube.com/watch?v=SWYqp7iY_Tc)

## Online Courses to follow:
* Learn Git on [Codecademy](https://www.codecademy.com/learn/learn-git)
* Learn Git on [Udemy](https://www.udemy.com/git-complete)
